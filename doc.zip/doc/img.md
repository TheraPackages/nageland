### `<img>` of Element
`<img>` 作用同 `<image>`一样。

**注意** <br/>
推荐使用`<image>`。

### 示例

```html
<template>
  <div>
    <img style="width: 560; height: 560;" src="https://img.alicdn.com/tps/TB1z.55OFXXXXcLXXXXXXXXXXXX-560-560.jpg" />
  </div>
</template>
```

### `<style>` of Element
`<style>` 组件是weex的样式标签，其内部存放的是weex的标签样式定义。

### 示例

```html
<template>
  <div class='back'>
  <div>
<template>
<style>
  .back {
    background-color: black;
  }
</style>
```

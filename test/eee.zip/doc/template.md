### `<template>` of Element
`<template>` 组件是weex的顶级布局容器。所有的布局都包含在其中。

### 示例
一个空的weex页面：
```html
<template>
<template>
<style>
</style>
<script>
</script>
```
